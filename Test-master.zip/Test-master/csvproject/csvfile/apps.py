from django.apps import AppConfig


class CsvfileConfig(AppConfig):
    name = 'csvfile'
